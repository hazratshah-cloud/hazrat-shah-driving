# 🚗 Hill Climber

A simple hill-climbing car game built with Python and Streamlit.

## Features

- Car climbing gameplay
- Speed
- Fuel
- Coins
- Distance
- Simple mountain display
- Optional Groq AI-generated challenges
- Streamlit UI

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Groq AI setup

Create a `.streamlit` folder and add `secrets.toml`:

```toml
GROQ_API_KEY = "YOUR_GROQ_API_KEY"
```

Never upload your API key to GitHub.

For Streamlit Community Cloud, add the same secret through the app's Secrets settings.
