import math
import random

import streamlit as st


st.set_page_config(
    page_title="Hill Climber",
    page_icon="🚗",
    layout="centered",
)

st.title("🚗 Hill Climber")
st.caption("Climb the mountain. Collect coins. Don't crash!")


defaults = {
    "distance": 0,
    "fuel": 100,
    "coins": 0,
    "speed": 0,
    "game_over": False,
}

for key, value in defaults.items():
    if key not in st.session_state:
        st.session_state[key] = value


def get_hill_height(x):
    return 100 + 45 * math.sin(x / 35) + 20 * math.sin(x / 12)


def reset_game():
    for key, value in defaults.items():
        st.session_state[key] = value


def generate_ai_content():
    from groq import Groq

    client = Groq(api_key=st.secrets["GROQ_API_KEY"])

    response = client.chat.completions.create(
        model="openai/gpt-oss-20b",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a creative game designer. "
                    "Create short content for a hill climbing car game."
                ),
            },
            {
                "role": "user",
                "content": (
                    "Create a fun hill name, a short challenge, "
                    "and one driving tip. Keep everything short."
                ),
            },
        ],
    )

    return response.choices[0].message.content


col1, col2, col3 = st.columns(3)

with col1:
    gas = st.button("🚀 GAS", use_container_width=True)

with col2:
    brake = st.button("🛑 BRAKE", use_container_width=True)

with col3:
    restart = st.button("🔄 NEW GAME", use_container_width=True)


if restart:
    reset_game()


if not st.session_state.game_over:
    if gas:
        st.session_state.speed += 5
        st.session_state.fuel -= 2
    elif brake:
        st.session_state.speed -= 5
    else:
        st.session_state.speed -= 1

    st.session_state.speed = max(0, min(st.session_state.speed, 30))
    st.session_state.distance += st.session_state.speed

    if random.random() < 0.08:
        st.session_state.coins += 1

    if st.session_state.fuel <= 0:
        st.session_state.fuel = 0
        st.session_state.game_over = True


st.divider()

col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Distance", f"{st.session_state.distance} m")

with col2:
    st.metric("Speed", f"{st.session_state.speed} km/h")

with col3:
    st.metric("Coins", st.session_state.coins)

st.progress(
    st.session_state.fuel / 100,
    text=f"Fuel: {st.session_state.fuel}%",
)


st.subheader("🏔️ Mountain")

distance = st.session_state.distance
hill = get_hill_height(distance)

st.write(
    f"""
```
                🚩
          /\\            /\\
         /  \\____  ____/  \\
    _____/             \\_____
                 🚗
                🛞 🛞

    Hill height: {hill:.0f} m
    Distance: {distance} m
```
"""
)


if st.session_state.game_over:
    st.error("💥 Game Over!")

    if st.session_state.fuel <= 0:
        st.warning("You ran out of fuel.")

    st.info("Press NEW GAME to try again.")


st.divider()
st.subheader("🤖 AI Game Master")

if "GROQ_API_KEY" in st.secrets:
    if st.button("✨ Generate New Challenge", use_container_width=True):
        with st.spinner("AI is creating your challenge..."):
            try:
                content = generate_ai_content()
                st.info(content)
            except Exception as error:
                st.error(f"AI request failed: {error}")
else:
    st.info(
        "Groq AI is not configured yet. Add GROQ_API_KEY to "
        ".streamlit/secrets.toml or Streamlit Cloud Secrets."
    )

st.caption("Keep climbing! 🚗🏔️")
